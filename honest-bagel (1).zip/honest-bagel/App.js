import React, {useState} from 'react';
import {Alert, Button, View, Text, TextInput} from 'react-native';

function ItemContato ( props ) {
  return(
    <View>
      <Text>{props.item.nome}</Text>
      <Text>{props.item.telefone}</Text>
      <Text>{props.item.email}</Text>
    </View>
  )
};

export default function () { 
  const [nome, setNome] = useState("");
  const [telefone, setTelefone] = useState("");
  const [email, setEmail] = useState("");
  
  const [lista, setLista] = useState([]);


  const listaExibicao = [];

  for(let i = 0; i < lista.length; i++) {
    listaExibicao.push(
      <View>
        <Text> {lista[i].nome}</Text> 
        <Text> {lista[i].telefone}</Text> 
        <Text> {lista[i].email} </Text>  
      </View>
    );
  }


  return (
    <View style={{padding:30, backgroundColor:"gray"}}>
      <Text>Agenda de contato</Text>
      <Text>Nome: </Text>
      <TextInput style={{borderWidth:2, margin:5, backgroundColor:"azure"}} value={nome} onChangeText={setNome} />
      <Text>Telefone: </Text>
      <TextInput style={{borderWidth:2, margin:5, backgroundColor:"azure"}} value={telefone} onChangeText={setTelefone}/>
      <Text>Email: </Text>
      <TextInput style={{borderWidth:2, margin:8, backgroundColor:"azure"}} value={email} onChangeText={setEmail}/>
      
      <Button title="Ok" onPress={
        ()=> {
          const obj = {nome, telefone, email};
          const novaLista = [...lista, obj]
          setLista([...lista, obj])
        }
      }/>
        <View style={{backgroundColor:"azure", margin:9}}>
          <Text>Contatos:</Text>
          {listaExibicao}
      </View>
    </View>
  );
}
